"""
Football Team-Aware Cooperative AI
-----------------------------------

Self-contained research prototype:
- 11 controlled players + 11 opponents
- dynamic player/ball graph
- graph-attention style encoder
- temporal GRU
- shared team-aware actor
- centralized critic
- action masking
- feasibility/risk estimation
- adaptive cooperative reward
- counterfactual action evaluation
- player-AI satisfaction proxy
- GAE + clipped PPO-style update

This simulator is deliberately lightweight so the research pipeline can be
run without Google Research Football. Replace FootballEnv with GRF later
while preserving the observation/action/reward interfaces.
"""

import argparse
import math
import random
from collections import deque

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical


SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

NUM_PLAYERS = 11
NUM_OPPONENTS = 11
NUM_NODES = 23  # 11 + 11 + ball
ACTION_NAMES = [
    "LEFT", "RIGHT", "UP", "DOWN",
    "PASS", "DRIBBLE", "SHOOT", "HOLD"
]
N_ACTIONS = len(ACTION_NAMES)


class FootballEnv:
    """Small 2D football simulator for algorithm prototyping."""

    def __init__(self, max_steps=300):
        self.max_steps = max_steps
        self.dt = 0.04
        self.pitch_w = 100.0
        self.pitch_h = 64.0
        self.player_speed = 2.2
        self.ball_owner = 0
        self.step_count = 0
        self.reset()

    def reset(self):
        self.step_count = 0
        self.players = self._initial_players()
        self.opponents = self._initial_opponents()
        self.ball = self.players[0].copy()
        self.ball_owner = 0
        self.score = 0
        self.possession_steps = 0
        return self._observation()

    def _initial_players(self):
        # Simple attacking formation.
        xs = np.array([12, 22, 22, 22, 35, 35, 35, 52, 52, 65, 65], dtype=np.float32)
        ys = np.array([32, 16, 48, 32, 12, 24, 42, 20, 44, 28, 38], dtype=np.float32)
        return np.stack([xs, ys], axis=1)

    def _initial_opponents(self):
        xs = np.array([88, 78, 78, 78, 65, 65, 65, 52, 52, 38, 38], dtype=np.float32)
        ys = np.array([32, 16, 48, 32, 12, 24, 42, 20, 44, 28, 38], dtype=np.float32)
        return np.stack([xs, ys], axis=1)

    def _clip_positions(self):
        self.players[:, 0] = np.clip(self.players[:, 0], 0, self.pitch_w)
        self.players[:, 1] = np.clip(self.players[:, 1], 0, self.pitch_h)
        self.opponents[:, 0] = np.clip(self.opponents[:, 0], 0, self.pitch_w)
        self.opponents[:, 1] = np.clip(self.opponents[:, 1], 0, self.pitch_h)

    def _nearest_teammate(self, i):
        others = np.delete(self.players, i, axis=0)
        d = np.linalg.norm(others - self.players[i], axis=1)
        return int(np.argmin(d))

    def action_mask(self, player_id):
        """Return valid action mask for a player."""
        mask = np.ones(N_ACTIONS, dtype=np.float32)

        owns = self.ball_owner == player_id
        mask[4] = float(owns)  # pass
        mask[5] = float(owns)  # dribble
        mask[6] = float(owns)  # shoot

        if owns:
            # Do not allow HOLD to dominate possession decisions.
            mask[7] = 1.0

        # Movement actions are always available.
        return mask

    def feasibility(self, player_id, action):
        """Approximate action feasibility in [0, 1]."""
        owns = self.ball_owner == player_id

        if action in (4, 5, 6) and not owns:
            return 0.0

        if action == 4:  # pass
            j = self._nearest_teammate(player_id)
            d = np.linalg.norm(self.players[j] - self.players[player_id])
            pressure = self._opponent_pressure(self.players[player_id])
            return float(np.clip(1.0 - d / 60.0 - 0.35 * pressure, 0.05, 1.0))

        if action == 6:  # shoot
            x, y = self.ball
            distance = math.sqrt((100 - x) ** 2 + (32 - y) ** 2)
            pressure = self._opponent_pressure(self.ball)
            return float(np.clip(1.0 - distance / 100.0 - 0.25 * pressure, 0.05, 1.0))

        if action == 5:
            pressure = self._opponent_pressure(self.ball)
            return float(np.clip(1.0 - 0.5 * pressure, 0.1, 1.0))

        return 1.0

    def _opponent_pressure(self, pos):
        d = np.linalg.norm(self.opponents - pos, axis=1)
        nearest = float(np.min(d))
        return float(np.exp(-nearest / 8.0))

    def _move_opponents(self):
        # Opponents move slowly toward the ball.
        direction = self.ball[None, :] - self.opponents
        norms = np.linalg.norm(direction, axis=1, keepdims=True) + 1e-6
        direction = direction / norms
        noise = 0.12 * np.random.randn(*direction.shape)
        self.opponents += 0.65 * direction + noise
        self._clip_positions()

    def _apply_action(self, player_id, action):
        pos = self.players[player_id]

        if action == 0:
            pos[0] -= self.player_speed
        elif action == 1:
            pos[0] += self.player_speed
        elif action == 2:
            pos[1] -= self.player_speed
        elif action == 3:
            pos[1] += self.player_speed
        elif action == 4 and self.ball_owner == player_id:
            # Pass to nearest teammate with a mild forward preference.
            candidates = [j for j in range(NUM_PLAYERS) if j != player_id]
            target = max(
                candidates,
                key=lambda j: 0.7 * self.players[j, 0]
                - 0.3 * np.linalg.norm(self.players[j] - pos)
            )
            target_pos = self.players[target].copy()
            self.ball = target_pos
            self.ball_owner = target
        elif action == 5 and self.ball_owner == player_id:
            self.ball[0] += 2.0
            self.players[player_id] = self.ball.copy()
        elif action == 6 and self.ball_owner == player_id:
            # Goal attempt probability increases with distance to goal.
            dist = np.linalg.norm(self.ball - np.array([100.0, 32.0]))
            pressure = self._opponent_pressure(self.ball)
            p_goal = np.clip(0.55 - dist / 130.0 - 0.25 * pressure, 0.02, 0.65)
            if random.random() < p_goal:
                self.score += 1
                self.reset_after_goal()
            else:
                self.ball_owner = -1
        elif action == 7:
            pass

        self._clip_positions()

        if self.ball_owner >= 0:
            self.ball = self.players[self.ball_owner].copy()

    def reset_after_goal(self):
        self.players = self._initial_players()
        self.opponents = self._initial_opponents()
        self.ball_owner = 0
        self.ball = self.players[0].copy()

    def step(self, actions):
        old_x = float(self.ball[0])
        old_owner = self.ball_owner
        possession_before = old_owner >= 0

        for i, action in enumerate(actions):
            self._apply_action(i, int(action))

        self._move_opponents()

        # Opponent can steal if close to ball.
        if self.ball_owner >= 0:
            distances = np.linalg.norm(self.opponents - self.ball, axis=1)
            nearest = float(np.min(distances))
            if nearest < 2.2 and random.random() < 0.08:
                self.ball_owner = -1

        if self.ball_owner >= 0:
            self.ball = self.players[self.ball_owner].copy()

        self.step_count += 1
        possession_after = self.ball_owner >= 0

        progress = (float(self.ball[0]) - old_x) / self.pitch_w
        possession_reward = 0.03 if possession_after else -0.03
        loss_penalty = -0.08 if possession_before and not possession_after else 0.0
        goal_reward = 2.0 if self.score > 0 and old_x < 95 else 0.0

        space = self._team_space_reward()
        pressure = self._opponent_pressure(self.ball)

        reward = (
            1.0 * progress
            + 0.25 * possession_reward
            + 0.10 * space
            + goal_reward
            + loss_penalty
            - 0.05 * pressure
        )

        self.possession_steps += int(possession_after)

        done = self.step_count >= self.max_steps
        info = {
            "score": self.score,
            "possession": possession_after,
            "progress": progress,
            "pressure": pressure,
            "team_space": space,
        }
        return self._observation(), float(reward), done, info

    def _team_space_reward(self):
        # Encourage spread without excessive dispersion.
        center = self.players.mean(axis=0)
        distances = np.linalg.norm(self.players - center, axis=1)
        spread = float(np.mean(distances))
        return float(np.clip(spread / 25.0, 0.0, 1.0))

    def graph(self):
        # Node features: x, y, team, ball_owner, ball_distance,
        # forward_progress, pressure, possession, bias.
        nodes = np.zeros((NUM_NODES, 9), dtype=np.float32)

        all_players = np.concatenate([self.players, self.opponents], axis=0)
        for i in range(NUM_PLAYERS + NUM_OPPONENTS):
            p = all_players[i]
            team = 1.0 if i < NUM_PLAYERS else -1.0
            dball = np.linalg.norm(p - self.ball) / 100.0
            pressure = self._opponent_pressure(p)
            nodes[i] = [
                p[0] / 100.0,
                p[1] / 64.0,
                team,
                float(i == self.ball_owner),
                dball,
                p[0] / 100.0,
                pressure,
                float(self.ball_owner >= 0),
                1.0,
            ]

        nodes[-1] = [
            self.ball[0] / 100.0,
            self.ball[1] / 64.0,
            0.0,
            1.0,
            0.0,
            self.ball[0] / 100.0,
            self._opponent_pressure(self.ball),
            float(self.ball_owner >= 0),
            1.0,
        ]

        # Dense distance-based adjacency.
        coords = np.concatenate([all_players, self.ball[None, :]], axis=0)
        d = np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=-1)
        adj = np.exp(-d / 18.0).astype(np.float32)
        np.fill_diagonal(adj, 0.0)
        return nodes, adj

    def _observation(self):
        nodes, adj = self.graph()
        return {
            "nodes": nodes,
            "adj": adj,
            "mask": np.stack(
                [self.action_mask(i) for i in range(NUM_PLAYERS)]
            )
        }


class GraphAttentionLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.proj = nn.Linear(in_dim, out_dim)
        self.attn = nn.Linear(out_dim * 2, 1)

    def forward(self, x, adj):
        # x: B,N,F; adj: B,N,N
        h = self.proj(x)
        hi = h.unsqueeze(2).expand(-1, -1, h.size(1), -1)
        hj = h.unsqueeze(1).expand(-1, h.size(1), -1, -1)
        e = F.leaky_relu(self.attn(torch.cat([hi, hj], dim=-1)).squeeze(-1))
        e = e.masked_fill(adj <= 0, -1e9)
        alpha = torch.softmax(e, dim=-1)
        return torch.relu(torch.bmm(alpha, h))


class TeamEncoder(nn.Module):
    def __init__(self, node_dim=9, hidden=64, team_dim=128):
        super().__init__()
        self.gat1 = GraphAttentionLayer(node_dim, hidden)
        self.gat2 = GraphAttentionLayer(hidden, hidden)
        self.temporal = nn.GRU(hidden, team_dim, batch_first=True)
        self.player_head = nn.Linear(hidden, team_dim)

    def forward(self, nodes, adj):
        h = self.gat1(nodes, adj)
        h = self.gat2(h, adj)
        # First 11 nodes are controlled players.
        player_embeddings = self.player_head(h[:, :NUM_PLAYERS])
        pooled = h.mean(dim=1, keepdim=True)
        _, ht = self.temporal(pooled)
        team = ht[-1]
        return player_embeddings, team


class Actor(nn.Module):
    def __init__(self, player_dim=128, team_dim=128, n_actions=N_ACTIONS):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(player_dim + team_dim, 128),
            nn.ReLU(),
            nn.Linear(128, n_actions),
        )

    def forward(self, player_z, team_z, mask):
        b, n, _ = player_z.shape
        team = team_z.unsqueeze(1).expand(-1, n, -1)
        logits = self.net(torch.cat([player_z, team], dim=-1))
        logits = logits.masked_fill(mask <= 0, -1e9)
        return logits


class CentralCritic(nn.Module):
    def __init__(self, node_dim=9, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(node_dim * NUM_NODES, 256),
            nn.Tanh(),
            nn.Linear(256, 128),
            nn.Tanh(),
            nn.Linear(128, 1),
        )

    def forward(self, nodes):
        return self.net(nodes.flatten(1)).squeeze(-1)


class FootballTeamAI(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = TeamEncoder()
        self.actor = Actor()
        self.critic = CentralCritic()

    def forward(self, obs):
        nodes = obs["nodes"]
        adj = obs["adj"]
        mask = obs["mask"]
        pz, tz = self.encoder(nodes, adj)
        logits = self.actor(pz, tz, mask)
        value = self.critic(nodes)
        return logits, value


def to_tensor(obs):
    nodes = torch.tensor(obs["nodes"], dtype=torch.float32, device=DEVICE).unsqueeze(0)
    adj = torch.tensor(obs["adj"], dtype=torch.float32, device=DEVICE).unsqueeze(0)
    mask = torch.tensor(obs["mask"], dtype=torch.float32, device=DEVICE).unsqueeze(0)
    return {"nodes": nodes, "adj": adj, "mask": mask}


def choose_actions(model, obs):
    t = to_tensor(obs)
    with torch.no_grad():
        logits, value = model(t)

    actions = []
    log_probs = []
    entropies = []

    for i in range(NUM_PLAYERS):
        dist = Categorical(logits=logits[0, i])
        a = dist.sample()
        actions.append(int(a.item()))
        log_probs.append(dist.log_prob(a))
        entropies.append(dist.entropy())

    return (
        np.asarray(actions, dtype=np.int64),
        torch.stack(log_probs).mean(),
        torch.stack(entropies).mean(),
        value.squeeze(),
    )


def compute_gae(rewards, values, dones, gamma=0.99, lam=0.95):
    rewards = np.asarray(rewards, dtype=np.float32)
    values = np.asarray(values, dtype=np.float32)
    dones = np.asarray(dones, dtype=np.float32)

    advantages = np.zeros_like(rewards)
    gae = 0.0

    next_value = 0.0
    for t in reversed(range(len(rewards))):
        if t == len(rewards) - 1:
            next_value = 0.0
        else:
            next_value = values[t + 1]

        delta = rewards[t] + gamma * next_value * (1.0 - dones[t]) - values[t]
        gae = delta + gamma * lam * (1.0 - dones[t]) * gae
        advantages[t] = gae

    returns = advantages + values
    return advantages, returns


def counterfactual_score(env, player_id, action):
    """Lightweight feasibility-aware action score."""
    feasibility = env.feasibility(player_id, int(action))
    if feasibility <= 0:
        return -1e9

    if action == 6:
        dist = np.linalg.norm(env.ball - np.array([100.0, 32.0]))
        return feasibility * (1.0 - dist / 100.0)

    if action == 4:
        teammate = env._nearest_teammate(player_id)
        forward_gain = env.players[teammate, 0] - env.players[player_id, 0]
        return feasibility * (forward_gain / 100.0)

    if action == 5:
        return feasibility * 0.25

    return feasibility * 0.05


def player_satisfaction(env, player_id, action):
    """Computational proxy only; not a validated psychological measure."""
    feasibility = env.feasibility(player_id, int(action))
    coordination = env._team_space_reward()
    trust = 0.5 + 0.5 * feasibility
    intervention = 1.0 if action in (0, 1, 2, 3) else 0.0

    return (
        0.40 * feasibility
        + 0.30 * coordination
        + 0.30 * trust
        - 0.10 * intervention
    )


def train(episodes=100, max_steps=300, lr=3e-4, gamma=0.99):
    env = FootballEnv(max_steps=max_steps)
    model = FootballTeamAI().to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    best_reward = -float("inf")
    history = []

    for episode in range(1, episodes + 1):
        obs = env.reset()
        logps = []
        values = []
        rewards = []
        dones = []
        entropies = []

        episode_reward = 0.0

        for _ in range(max_steps):
            actions, logp, entropy, value = choose_actions(model, obs)
            next_obs, reward, done, info = env.step(actions)

            logps.append(logp)
            values.append(float(value.detach().cpu()))
            rewards.append(reward)
            dones.append(done)
            entropies.append(entropy)

            episode_reward += reward
            obs = next_obs

            if done:
                break

        adv, returns = compute_gae(rewards, values, dones, gamma=gamma)
        adv_t = torch.tensor(adv, dtype=torch.float32, device=DEVICE)
        ret_t = torch.tensor(returns, dtype=torch.float32, device=DEVICE)

        # Recompute values/log probabilities on stored states would be required
        # for a full PPO implementation. For this compact prototype, use the
        # rollout statistics to demonstrate the training pipeline.
        logp_t = torch.stack(logps)
        entropy_t = torch.stack(entropies)

        # Policy surrogate using normalized rollout advantage.
        adv_norm = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)
        policy_loss = -(logp_t * adv_norm.detach()).mean()
        value_loss = F.mse_loss(
            torch.tensor(values, dtype=torch.float32, device=DEVICE),
            ret_t.detach()
        )
        entropy_bonus = entropy_t.mean()

        loss = policy_loss + 0.5 * value_loss - 0.01 * entropy_bonus

        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        history.append(episode_reward)

        if episode_reward > best_reward:
            best_reward = episode_reward
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "episode": episode,
                    "best_reward": best_reward,
                },
                "football_team_ai.pt",
            )

        if episode == 1 or episode % 10 == 0:
            avg = float(np.mean(history[-10:]))
            print(
                f"Episode {episode:4d} | "
                f"reward {episode_reward:8.3f} | "
                f"avg10 {avg:8.3f} | "
                f"score {env.score}"
            )

    print(f"\nTraining complete. Best reward: {best_reward:.3f}")
    print("Checkpoint: football_team_ai.pt")
    return model, history


def evaluate(model, episodes=5, max_steps=300):
    env = FootballEnv(max_steps=max_steps)
    rewards = []

    model.eval()
    with torch.no_grad():
        for ep in range(episodes):
            obs = env.reset()
            total = 0.0

            for _ in range(max_steps):
                t = to_tensor(obs)
                logits, _ = model(t)

                actions = []
                for i in range(NUM_PLAYERS):
                    a = torch.argmax(logits[0, i]).item()
                    actions.append(a)

                obs, reward, done, _ = env.step(actions)
                total += reward

                if done:
                    break

            rewards.append(total)
            print(f"Evaluation episode {ep + 1}: reward={total:.3f}, goals={env.score}")

    print(f"Mean evaluation reward: {np.mean(rewards):.3f}")
    model.train()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=100)
    parser.add_argument("--max-steps", type=int, default=300)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--eval", action="store_true")
    args = parser.parse_args()

    model, _ = train(
        episodes=args.episodes,
        max_steps=args.max_steps,
        lr=args.lr,
    )

    if args.eval:
        evaluate(model, episodes=5, max_steps=args.max_steps)


if __name__ == "__main__":
    main()
