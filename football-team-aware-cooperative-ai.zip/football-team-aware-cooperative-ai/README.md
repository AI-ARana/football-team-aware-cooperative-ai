# Football Team-Aware Cooperative AI

A research prototype for cooperative football decision-making using multi-agent reinforcement learning (MARL), dynamic player relationships, temporal context, action masking, feasibility/risk estimation, adaptive reward shaping, counterfactual evaluation, and a player-AI satisfaction proxy.

## Architecture

```text
Football environment
        ↓
State extraction
        ↓
Dynamic player + ball graph
        ↓
Graph attention encoder
        ↓
Temporal GRU
        ↓
Shared team representation
        ↓
MAPPO/PPO-style actor-critic
        ↓
Action masking
        ↓
Feasibility + risk
        ↓
Counterfactual evaluation
        ↓
Team action
        ↓
Adaptive cooperative reward
        ↺
```

## Mathematical objective

\[
\pi^*=\arg\max_\pi E\left[\sum_t \gamma^t
(U_{team,t}+\lambda SAT_t-\eta Risk_t)\right]
\]

The current implementation is a self-contained 2D research simulator. It is intended for algorithm development and ablation experiments; it is not a validated real-football performance system.

## Main features

- 11 controlled players and 11 opponents
- Dynamic player-ball graph
- Graph-attention style message passing
- Temporal GRU encoder
- Shared team-aware policy
- Action masking
- Action feasibility and risk score
- Adaptive reward shaping
- Counterfactual action scoring
- Player-AI satisfaction/trust proxy
- GAE and clipped PPO-style optimization
- Checkpoint saving
- Deterministic evaluation mode

## Installation

```bash
python -m pip install -r requirements.txt
```

## Run training

```bash
python football_team_ai.py --episodes 100
```

For a quick test:

```bash
python football_team_ai.py --episodes 5
```

A checkpoint is saved as:

```text
football_team_ai.pt
```

## Research progression

1. SARSA baseline
2. PPO baseline
3. Cooperative MAPPO
4. GNN + MAPPO
5. GNN + temporal encoder + MAPPO
6. Action masking
7. Feasibility/risk estimation
8. Adaptive reward shaping
9. Counterfactual decision evaluation
10. Player-AI feedback/satisfaction validation

## Future integration

The simulator can later be replaced with Google Research Football (GRF) or real tracking/event data. Keep the state/action/reward interfaces stable so the learning components can be evaluated independently.

## Important research limitation

The satisfaction term is only a computational proxy. It must not be interpreted as a validated psychological measurement until it is calibrated against player feedback and validated experimentally.
