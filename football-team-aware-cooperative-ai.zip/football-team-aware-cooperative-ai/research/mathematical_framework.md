# Mathematical Research Framework

## 1. Football as a cooperative Dec-POMDP

\[
M=(S,\{O_i\},\{A_i\},P,R,\gamma)
\]

where:

- \(S\): global game state
- \(O_i\): observation available to player \(i\)
- \(A_i\): action set of player \(i\)
- \(P\): transition function
- \(R\): reward
- \(\gamma\): discount factor

## 2. Dynamic graph

\[
G_t=(V_t,E_t)
\]

Nodes represent the 22 players and the ball. Edge features can include distance, pressure, passing-lane visibility, teammate/opponent relation, and spatial proximity.

## 3. Graph encoder

\[
z_t=f_\theta(G_t)
\]

A message-passing layer can be written as:

\[
h_i'=\sigma\left(W_s h_i+
\sum_{j\in N(i)}\alpha_{ij}W_nh_j\right)
\]

with attention coefficient:

\[
\alpha_{ij}=
\frac{\exp(e_{ij})}
{\sum_{k\in N(i)}\exp(e_{ik})}.
\]

## 4. Temporal representation

Given recent graph embeddings:

\[
z_{t-k},...,z_t
\]

the temporal encoder produces:

\[
h_t=GRU(z_{t-k:t}).
\]

This allows the model to use movement trends rather than only the current frame.

## 5. Action masking

Let \(M_i(s,a)\in\{0,1\}\). Then:

\[
A_i'(s)=\{a\in A_i:M_i(s,a)=1\}.
\]

Examples:

- do not shoot when the player does not possess the ball
- do not pass when no teammate is available
- do not tackle when there is no opponent close enough

## 6. Feasibility and risk

\[
Score(s,a)=Q(s,a)-\lambda Risk(s,a)+\mu Feasibility(s,a)
\]

where feasibility is in \([0,1]\).

## 7. Adaptive cooperative reward

\[
R_t=w_gR_{goal}+w_pR_{possession}+w_xR_{progress}
+w_sR_{space}-w_lR_{loss}-w_rR_{risk}.
\]

Weights can depend on:

- score difference
- remaining time
- possession
- field position
- defensive pressure

## 8. Counterfactual evaluation

\[
\Delta U(a)=U(s,a)-U(s,a_{alt}).
\]

This estimates the marginal utility of the selected action relative to an alternative.

## 9. Player-AI satisfaction proxy

\[
SAT_i=\alpha Q_i+\beta C_i+\gamma T_i-\delta I_i
\]

where the terms may represent action quality, coordination, trust, and unwanted intervention.

This is a computational proxy, not a clinically or psychologically validated scale.

## 10. Overall optimization

\[
\pi^*=
\arg\max_\pi
E\left[
\sum_t\gamma^t
(U_{team,t}+\lambda SAT_t-\eta Risk_t)
\right].
\]

The scientific contribution should ultimately be demonstrated through controlled baselines, ablations, uncertainty analysis, and validation on real or standardized football datasets.
